package com.bhavna.file;

import java.text.SimpleDateFormat;
import java.util.Map;

public interface PersonDetails {
	public void getFileDetails();
	public void getDetailsBySplit();
	Map<String, SimpleDateFormat>  ProcessingFileData(String[] s1);
}
