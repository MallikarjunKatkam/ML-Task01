package com.bhavna.model;

import java.text.SimpleDateFormat;

public class PersonsLoginData {
	private String name;
	private SimpleDateFormat date;
	
	public PersonsLoginData() {
	}
	
	public PersonsLoginData(String name, SimpleDateFormat date) {
		this.name = name;
		this.date = date;
	}
	public SimpleDateFormat getDate() {
		return date;
	}
	public void setDate(SimpleDateFormat date) {
		this.date = date;
	} 
}
