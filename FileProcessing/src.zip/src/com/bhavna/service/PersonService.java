package com.bhavna.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Map;

import com.bhavna.exceptions.MyException;
import com.bhavna.file.PersonDetails;

public class PersonService implements PersonDetails {

	@Override
	public void getFileDetails() {
		try (BufferedReader br = new BufferedReader(new FileReader("a.txt"));) {
			String[] s = null;
			while (br.ready()) {
				s=br.readLine().trim().split(" ");
				for (String str : s)
					System.out.println(str);
			}
			String sname1=s[0];
			String sname2=s[1];
			String sname3=s[2];
			System.out.println();
			System.out.println(sname1);
			System.out.println(sname2);
			System.out.println(sname3);
			System.out.println();
//			ProcessingFileData(s);
		}
//		catch(MyException myExc) {
//			myExc.printStackTrace();			
//		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	@Override
	public void getDetailsBySplit() {
	}

	@Override
	public Map<String, SimpleDateFormat> ProcessingFileData(String[] s1) {
//		int count = 0;
//		for (int i = 0; i < s1.length; i++) {
//			String sname = s1[i];
//			for (int j = 1; j < s1.length; j++) {
//				if (sname == s1[j]) {
//					count++;
//					System.out.println(sname);
//				}
//			}
//		}
//		BufferedReader in = null;
//		try
//		{
//			in = new BufferedReader(new FileReader("a.txt"));
//			String read = null;
//			while ((read = in.readLine()) != null) {
//				String[] splited = read.split("\\s+");
//				for (String part : splited) {
//					System.out.println(part);
//				}
//			}
//		}catch(
//		IOException e)
//		{
//			System.out.println("There was a problem: " + e);
//			e.printStackTrace();
//		}finally
//		{
//			try {
//				in.close();
//			} catch (Exception e) {
//			}
//		}
		return null;
	}

//	BufferedReader in = null;
//	try
//	{
//		in = new BufferedReader(new FileReader("a.txt"));
//		String read = null;
//		while ((read = in.readLine()) != null) {
//			String[] splited = read.split("\\s+");
//			for (String part : splited) {
//				System.out.println(part);
//			}
//		}
//	}catch(
//	IOException e)
//	{
//		System.out.println("There was a problem: " + e);
//		e.printStackTrace();
//	}finally
//	{
//		try {
//			in.close();
//		} catch (Exception e) {
//		}
//	}
}
