package com.bhavna.exceptions;

public class MyException extends Exception {

	public MyException(String msg) {
		super(msg);
	}
}
