package com.bhavna.fileprocessing;

import com.bhavna.file.PersonDetails;
import com.bhavna.service.PersonService;

public class MainClass {

	public static void main(String[] args) {
		PersonDetails pd=new PersonService();
		pd.getFileDetails();
	}

}
